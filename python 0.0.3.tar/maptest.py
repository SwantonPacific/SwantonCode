import os
import pygame
import time
import sys
import threading
from pygame.locals import *
from gps import *
#from time import *

#CONSTANTS
DISPLAY_WIDTH = 1280
DISPLAY_HEIGHT = 720

WSCALE_TRAIN1 = 40
HSCALE_TRAIN1 = 40

WSCALE_TRAIN2 = 40
HSCALE_TRAIN2 = 40

# handles reference point
# will have to change with location
#longitude is width, latitude is height
GPS_LAT_ORIGIN = 35.3004
GPS_LONG_ORIGIN = 120.6616


gpsd = None #global gpsd variable
gpsp = None 

os.system('clear')#clears terminal

class GpsPoller(threading.Thread):
        def __init__(self):
                threading.Thread.__init__(self)
                global gpsd #bring it in scope
                gpsd = gps(mode=WATCH_ENABLE) #starting the stream of info
                self.current_value = None
                self.running = True #setting the thread running to true

        def run(self):
                global gpsd
                while gpsp.running:
                        gpsd.next() #grab each set of gpsd info clear buffer
 
def checkEvent(): #checks if the users tries to quit or ESC key
	for event in pygame.event.get():
		if event.type == pygame.KEYDOWN:
			if (event.key == pygame.K_ESCAPE):
                                os.system('clear')
                                print "Exiting..."
                                gpsp.running = False
                                gpsp.join
                                pygame.display.quit()
                                pygame.quit()
                                print "Done\n"
				sys.exit(1)
		elif event.type == QUIT:
                        os.system('clear')
                        print "Exiting..."
                        gpsp.running = False
                        gpsp.join
                        pygame.display.quit()
                        pygame.quit()
                        print "Done\n"
			sys.exit(1) 

def update_trains(): 
    global train1_pos, train2_pos
    #build image in cache
    displaySurface.blit(base_img,(0,0))
    displaySurface.blit(train1_img, train1_pos)
    displaySurface.blit(train2_img, train2_pos)
    #send image to display
    pygame.display.update()

def train_demo():
    global train1_pos, train2_pos
    interval_time = .2

    #move trains around for demo    
    D_off = 100 #display offset
    t1w = 300
    t1h = 600
    t2w = 600
    t2h = 500
    	
    while True:
        #run pygame internals
        try:    
                pygame.event.pump()

                #need to determine scheme for taking pos from NEMA
                #for now mimicing train movement

                t1w = (t1w % DISPLAY_WIDTH) + D_off # moves trains around, just cuz
                t2w = (t2w % DISPLAY_WIDTH) + D_off

                #if( gpsd.fix.longitude - GPS_LONG_ORIGIN  < DISPLAY_WIDTH
                #   and gpsd.fix.longitude - GPS_LONG_ORIGIN > 0):
                train1_pos = (gpsd.fix.longitude - GPS_LONG_ORIGIN + t1w, t1h)
                train2_pos = (gpsd.fix.longitude - GPS_LONG_ORIGIN + t2w, t2h)        

##                if( gpsd.fix.longitude - GPS_LONG_ORIGIN  < DISPLAY_WIDTH and
##                    gpsd.fix.longitude - GPS_LONG_ORIGIN  > 0):
##                        train1_pos = (gpsd.fix.longitude - GPS_LONG_ORIGIN + 500, t1h)
##                        train2_pos = (gpsd.fix.longitude - GPS_LONG_ORIGIN + 300, t2h)        

                checkEvent();
                update_trains()
                

                os.system('clear')
                print
                print ' GPS reading'
                print '----------------------------------------'
                print 'latitude    ' , gpsd.fix.latitude
                print 'longitude   ' , gpsd.fix.longitude
                print 'time utc    ' , gpsd.utc,' + ', gpsd.fix.time
                print 'altitude (m)' , gpsd.fix.altitude
                print 'speed (m/s) ' , gpsd.fix.speed
                print 'climb       ' , gpsd.fix.climb
                print 'track       ' , gpsd.fix.track
                print 'mode        ' , gpsd.fix.mode
                print

                time.sleep(interval_time)
        except:
                print "Invalid Coordinate\n"


# this is our main() function
if __name__ == '__main__':

        gpsp = GpsPoller() #make thread
        try:
                gpsp.start() #start it up
        except:
                print "Error Starting GPS\n"
                sys.exit(1)
       
        pygame.init()
        #displaySurface = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        displaySurface = pygame.display.set_mode((DISPLAY_WIDTH,DISPLAY_HEIGHT))

        display = pygame.display.Info()
        #print(display.current_w, display.current_h)
        base_img = pygame.image.load("swanton.png")
        base_img = pygame.transform.scale(base_img,(display.current_w, display.current_h))
        train1_img = pygame.image.load("train1.png")
        train1_img = pygame.transform.scale(train1_img,(WSCALE_TRAIN1, HSCALE_TRAIN1))
        train2_img = pygame.image.load("train2.png")
        train2_img = pygame.transform.scale(train2_img,(WSCALE_TRAIN2, HSCALE_TRAIN2))
        displaySurface.blit(base_img,(0,0))
        
        train_demo()


